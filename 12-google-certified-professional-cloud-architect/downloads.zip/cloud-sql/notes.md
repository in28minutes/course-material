## SQL to execute

```sql

create table user 
(
    id integer, 
    username varchar(30)
);

describe user;

insert into user values (1, 'Ranga');

insert into user values (2, 'Ravi');

insert into user values (3, 'John');

insert into user values (4, 'Jane');

select * from user

```

